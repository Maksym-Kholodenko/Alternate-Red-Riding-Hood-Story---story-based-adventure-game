state = {
    "name": "",
    "trait": ""
}